import java.util.*;

/**
 * @author Sarah Alyahyaei
 * @date 7 Dec 2018
 * Aim : This class is to store filings names and then show to the user menu to choose
 */
public class Filings extends Food implements Ingerdintes {


    @Override
    public double storeDate(String name) {
      return 0;

    }

    /**
     *
     * @return list of chooses to the user
     */
    @Override
    public String meun() {
        Map<String, Double> filings = new HashMap<>();
        //1
        Filings cucumber = new Filings();
        cucumber.setName("Cucumber");
        cucumber.setCost(0.0);
        filings.put(cucumber.getName(), cucumber.getCost());

        //2
        Filings jalapenos = new Filings();
        jalapenos.setName("Jalapenos");
        jalapenos.setCost(0.0);
        filings.put(jalapenos.getName(), jalapenos.getCost());


        //3
        Filings lettuce = new Filings();
        lettuce.setName("Lettuce");
        lettuce.setCost(0.0);
        filings.put(lettuce.getName(), lettuce.getCost());

        //4
        Filings olives = new Filings();
        olives.setName("Olives");
        olives.setCost(0.0);
        filings.put(olives.getName(), olives.getCost());


        //5
        Filings peppers = new Filings();
        peppers.setName("Peppers");
        peppers.setCost(0.0);
        filings.put(peppers.getName(), peppers.getCost());


        //6
        Filings pickles = new Filings();
        pickles.setName("Pickles");
        pickles.setCost(0.0);
        filings.put(pickles.getName(), pickles.getCost());


        //7
        Filings tomato = new Filings();
        tomato.setName("Tomato");
        tomato.setCost(0.0);
        filings.put(tomato.getName(), tomato.getCost());


        //8
        Filings none = new Filings();
        none.setName("None");
        none.setCost(0.0);
        filings.put(none.getName(), none.getCost());
        Set key = filings.keySet();
        return String.format("%s%n",key);
    }
}
