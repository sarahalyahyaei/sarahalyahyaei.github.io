package test;

import junit.framework.TestCase;
import main.Card;
import main.Suit;
import main.Value;
import org.junit.jupiter.api.Test;

/**
 * @ Tester : Sarah Al Yahyaei
 * @ Date: 26 Feb 2019
 * Faults have been found :
 * 1- method isSameSuit
 * 2- toString method
 * 3-equals method it returns true when two objects of cards
 * are different
 *4- hashCode
 */
class CardTest extends TestCase {

    @Test
    void getSuit() {
        Card card = new Card(Suit.CLUBS, Value.ACE);
        //Expected suit
        Object h = Suit.CLUBS;
        assertEquals(h,card.getSuit());
    }

    @Test
    void getValue() {
        Card card = new Card(Suit.CLUBS,Value.ACE);
        //Expected value
        Object w = Value.ACE;
        assertEquals(w,card.getValue());
    }

    @Test
    void toStringPrint() {
        Card card = new Card(Suit.CLUBS,Value.ACE);
        String expected =
                "Card [suit="+Suit.CLUBS+", value="+Value.ACE+"]";
        assertEquals(expected,card.toString());
    }

    @Test
    void testHashCode() {
        Card card = new Card(Suit.CLUBS,Value.ACE);
        Card card1 = new Card(Suit.CLUBS,Value.ACE);
        assertEquals(card.hashCode(),card1.hashCode());
    }

    @Test
    void testUnequalObjectsHashCode(){
        Card card = new Card(Suit.CLUBS,Value.ACE);
        Card card1 = new Card(Suit.HEARTS,Value.ACE);
        assertEquals(card.hashCode(),card1.hashCode());
        //Expected is different ints
        // this test should be failed
    }

    /** Equals method in many conditions like when its true or false
     *
     */

    @Test
    void equalsValueTrue() {
        Card card = new Card(Suit.CLUBS,Value.ACE);
        boolean expected = true;
        assertEquals(expected,card.equals(card));

    }

    //After testing this method a fault has been found through if condition
    @Test
    void equalsValueFalse(){
        Card card = new Card(Suit.DIAMONDS,Value.EIGHT);
        Card card1 = new Card(Suit.CLUBS,Value.ACE);
        boolean expected = false;
        assertEquals(expected ,card.equals(card1));
    }




    ////////////////////////////////////////////

    /** isSameSuit and isSameValue methods with testing in two conditions
     *
     */
    @Test
    void isSameSuitFalse() {
        Card card = new Card(Suit.CLUBS,Value.ACE);
        Card card1 = new Card(Suit.DIAMONDS,Value.EIGHT);
        boolean s1 = false;
        assertEquals(s1, card1.isSameSuit(card));
    }

    @Test
    void isSameSuitTrue(){
        Card card = new Card(Suit.SPADES,Value.ACE);
        Card card1 = new Card(Suit.SPADES,Value.ACE);
        boolean s1 = true;
        assertEquals(s1,card1.isSameSuit(card));
    }

    @Test
    void isSameValueTrue() {
        Card card = new Card(Suit.DIAMONDS, Value.ACE);
        Card card1 = new Card(Suit.SPADES,Value.ACE);
        boolean h = true;
        assertEquals(h,card.isSameValue(card1));
    }

    @Test
    void isSameValueFalse(){
        Card card = new Card(Suit.SPADES, Value.ACE);
        Card card1 = new Card(Suit.SPADES,Value.EIGHT);
        boolean h = false;
        assertEquals(h,card.isSameValue(card1));

    }

    //////////////////////////////////////////////
}