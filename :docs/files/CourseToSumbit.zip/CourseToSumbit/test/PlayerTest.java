package test;

import junit.framework.TestCase;
import main.Card;
import main.Player;
import main.Suit;
import main.Value;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

public class PlayerTest extends TestCase {

    @Test
    public void getNameTrue() {
        Player p = new Player("Sarah");
        String expe = "Sarah";
        assertEquals(expe,p.getName());
        }

    @Test
    public void isAI() {
        Player p = new Player();
        boolean exp = true;
        assertEquals(true,p.isAI());
    }

    @Test
    public void getHand() {
        //Actual
        Card card = new Card(Suit.SPADES,Value.ACE);
        Card card1 = new Card(Suit.SPADES,Value.ACE);
        Player p = new Player("Sarah");
        ArrayList<Card> cards = new ArrayList <>();
        cards.add(card);
        cards.add(card1);
        p.setHand(cards);

        //Expected
        ArrayList<Card> cards1 = new ArrayList <>();
        Card card13 = new Card(Suit.SPADES,Value.ACE);
        Card card12 = new Card(Suit.SPADES,Value.ACE);
        cards1.add(card13);
        cards1.add(card12);

        assertEquals(cards1,p.getHand());

    }

    @Test
    public void toStringPrint() {
        Card card = new Card(Suit.SPADES, Value.ACE);
        Player player = new Player("Sarah");
        String expected= "Player [name="+player.getName()+", hand="
                +player.getHand()+"]";
        assertEquals(expected,player.toString());

    }

    @Test
    public void addCardToHand() {
        //Actual
        Card card = new Card(Suit.SPADES, Value.ACE);
        Player player = new Player();
        boolean ex = true;
        assertEquals(true, player.addCardToHand(card));
    }

    @Test
    public void getHandSize() {
        Card card = new Card(Suit.SPADES,Value.ACE);
        Card card1 = new Card(Suit.SPADES,Value.ACE);
        Player p = new Player("Sarah");
        ArrayList<Card> cards = new ArrayList <>();
        cards.add(card);
        cards.add(card1);
        p.setHand(cards);
        int exSize = 2;
        assertEquals(exSize, p.getHandSize());
    }



    @Test
    public void hasWon() {
        Card card = new Card(Suit.SPADES,Value.ACE);
        Card card1 = new Card(Suit.SPADES,Value.ACE);
        Player p = new Player("Sarah");
        ArrayList<Card> cards = new ArrayList <>();
        cards.add(card);
        cards.add(card1);
        p.setHand(cards);
        boolean expected = false;
        assertEquals(false,p.hasWon());
    }
}