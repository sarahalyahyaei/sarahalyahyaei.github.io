import java.util.Scanner;

/**
 * @author Sarah Al Yahyaei
 * @author 11 Dec 2018
 * This class is for formatting scanner to the user
 */
public class FilingsMultiplesForUser {

    // To have several filings:
    public static void filingsSanwich1() {
        boolean stop = false;
        Scanner input = new Scanner(System.in);

        while ((!stop)) {
            String filings = input.nextLine();
            String finish = "Stop";
            if (filings.equalsIgnoreCase(finish)) {
                stop = true;
                break;

            }
        }
    }
}
