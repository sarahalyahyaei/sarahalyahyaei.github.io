package main;

public enum Suit {
	CLUBS, DIAMONDS, HEARTS, SPADES
}
