package test;

import main.*;

import java.util.ArrayList;

/**
 * @author sarah alyhayaei
 */
public class Test {

	public static void main(String[] args){
		/**
		 * Testing for Player Class
		 * to test getHandAsString method
		 */
		Card card = new Card(Suit.SPADES, Value.ACE);
		Card card1 = new Card(Suit.SPADES,Value.ACE);
		Player p = new Player("Sarah");
		ArrayList <Card> cards = new ArrayList <>();
		cards.add(card);
		cards.add(card1);
		p.setHand(cards);
		System.out.println("Expected 1: [Card [suit=SPADES, value=ACE]");
		System.out.println("Expected 2: [Card [suit=SPADES, value=ACE]");
		System.out.println("=============================================");
		System.out.println(p.getHandAsString());
		
	}


	
}