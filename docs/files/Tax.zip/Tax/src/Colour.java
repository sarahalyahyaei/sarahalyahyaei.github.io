
/**
 * Enumeration class Colour - write a description of the enum class here
 * 
 * @P.A. Lee
 * @version (version number or date here)
 */
public enum Colour
{
	RED, YELLOW, BLUE, GREEN, MAGENTA, BLACK
}
