package main;

public class Card {

    // instance variables
    private final Suit suit;
    private final Value value;

    public Card(Suit suit, Value value) {
        this.suit = suit;
        this.value = value;
    }

    public Suit getSuit() {
        return suit;
    }

    public Value getValue() {
        return value;
    }

    /**
     * Error
     *
     * @return
     */
    @Override
    public String toString() {
        return "Card [suit=" + value + ", value=" + suit + "]";
      //  return "Card [suit=" + suit + ", value=" + value + "]";
    }

    /** Error
     * This method won't return the hashcode because of last line
     * return this.hashCode(); which something we are
     * not interested in
     *
     * @return
     */
    @Override
    public int hashCode() {
        final int prime = 15;
        int result = 1;
        result = prime * result + ((suit == null) ? 0 : suit.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return this.hashCode();
      // return result;
    }

    @Override
    /**
     * equals method should return false if the
     * two objects are not the same in memory
     */
    public boolean equals(Object obj) {
        if (this != obj)
            return true;
           // return false;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Card other = (Card) obj;
        if (suit != other.suit)
            return false;
        if (value != other.value)
            return false;
        return true;
    }

    /** FAULT
     *
     * @param card
     * @return true if the two card have the same suit
     * which mean the return should be like this
     * this.suit.equals(card.getSuit());
     */
    public boolean isSameSuit(Card card) {
        return this.suit.equals(card.getValue());
       // return this.suit.equals(card.getSuit());
    }

    public boolean isSameValue(Card card) {
        return this.value.equals(card.getValue());
    }
}
